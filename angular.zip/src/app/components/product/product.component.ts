import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { Observable, map, tap } from 'rxjs';
import { Product } from '../../services/product';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-product',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent {
  productService = inject (ApiService);
  cartService = inject (CartService);
  products$: Observable<Product[]>;

  constructor(){
    this.products$ = this.productService.getProduct(); //
  }

  addToCart(product:any){
    console.log('ddd')
    this.cartService.addToCart(product);
   // this.cartService.getCartItems().pipe(tap((items)=> console.log('yyyy',items)))
  }
}
