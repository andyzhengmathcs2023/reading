import { Component, OnInit, Signal, computed, effect, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import { CartItem } from '../../services/cart-item';
import { CartService } from '../../services/cart.service';
import { RouterLink } from '@angular/router';
import {signal} from '@angular/core';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css' //
})
export class CartComponent implements OnInit{
  cartService= inject(CartService);
  cartItemListSig = inject(CartService).cartItemListSig;

 cartItems = computed(()=> this.cartService.cartItemListSig());
 cartEmpty1 = computed(()=> this.cartService.cartItemListSig().length===0);
 cartEmpty = computed(()=> this.cartItemListSig().length===0);
 grandTotal= 0;
 
 ngOnInit(){
    this.grandTotal= this.cartService.getTotalPrice();
 }

 removeItem(item:CartItem){
  this.cartService.removeCartItem(item);
 }

 removeAll(){
  this.cartService.removeAllCart();
 }
}
 