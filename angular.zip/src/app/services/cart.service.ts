import { Injectable, computed, signal } from '@angular/core';
import { BehaviorSubject, Observable, from, map, of } from 'rxjs';
import { CartItem } from './cart-item';
import { Product } from './product';
//import groupBy from 'lodash/groupBy';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  public cartItemListSig = signal<CartItem[]>([]);
  public productListSig = signal<Product[]>([]); //new BehaviorSubject<CartItem[]>([])
  constructor() {}

  getProducts(): CartItem[] {
    return this.cartItemListSig();
  }

  setProduct(product: CartItem) {
    this.cartItemListSig.update((ps) => [...ps, product]);
  }

  addToCart(p: Product) {
    const newCartItem = {
      id: p.id,
      productName: p.title,
      productImg: p.image,
      description: p.description,
      price: p.price,
      quantiy:1 ,
      total: 1*p.price,
      action: 'aaa',
    };
  
    this.cartItemListSig.update((cs) => [...cs, newCartItem]);
    this.getTotalPrice();
  }

  getTotalPrice(): number{
    let grandTotal = 0;
    this.cartItemListSig().map((item: CartItem) => {
      //item.total = item.price * item.quantiy;
      grandTotal+= item.total;
    });
    return grandTotal;
  }

  removeCartItem(product: CartItem) {
    this.cartItemListSig.update((items)=>items.filter((item)=> item.id!==product.id));
  }

  removeAllCart() {
    this.cartItemListSig.set([]);
  }
  
}
