import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Product } from './product';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  http = inject(HttpClient);
  constructor() {}
  url = 'https://fakestoreapi.com/products';
  
  getProduct() {
    return this.http.get<Product>(this.url).pipe(
      map((res: any) => {
        return res;
      })
    );
  }
}
