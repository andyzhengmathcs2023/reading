import { DecimalPipe } from "@angular/common";

export interface CartItem {
    id:number,
    productName:string,
    productImg: string,
    description: string,
    price: number,
    quantiy: number,
    total: number,
    action: string
}


