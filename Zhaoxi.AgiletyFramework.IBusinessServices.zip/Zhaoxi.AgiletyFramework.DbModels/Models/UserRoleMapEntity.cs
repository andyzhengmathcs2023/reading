﻿
using System;

namespace Zhaoxi.AgiletyFramework.DbModels.Models
{
    /// <summary>
    /// 用户角色映射表
    /// </summary> 
    public class UserRoleMapEntity : BaseModel
    { 
        public int Id { get; set; }
         
        public int UserId { get; set; }
         
        public int RoleId { get; set; }
    }
}
