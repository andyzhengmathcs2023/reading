﻿
using System;

namespace Zhaoxi.AgiletyFramework.DbModels.Models
{
    /// <summary>
    /// 用户信息---用作和数据库映射的实体对象
    /// </summary> 
    public class UserEntity:BaseModel
    {
        public int UserId { get; set; }
        public string? Name { set; get; }

        public string? Password { set; get; }

        /// <summary>
        /// 用户类型--UserTypeEnum  
        /// 1:管理员 系统默认生成
        /// 2:普通用户  添加的或者注册的用户都为普通用户
        /// </summary> 
        public int UserType { get; set; }

        public string? Phone { set; get; }

        public string? Mobile { set; get; }

        public string? Address { set; get; }

        public string? Email { set; get; }
        public string? QQ { set; get; }

        public string? WeChat { set; get; }

        public int Sex { set; get; }

        /// <summary>
        /// 用户头像
        /// </summary> 
        public string? Imageurl { set; get; }

        public DateTime LastLoginTime { set; get; }
    }
}
