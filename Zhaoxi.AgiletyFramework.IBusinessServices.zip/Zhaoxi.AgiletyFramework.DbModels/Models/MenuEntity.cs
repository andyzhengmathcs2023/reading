﻿

using Castle.Components.DictionaryAdapter;

namespace Zhaoxi.AgiletyFramework.DbModels.Models
{
     
    public class MenuEntity : BaseModel
    {
        /// <summary>
        /// 主键Id
        /// </summary> 
        public Guid Id { get; set; }

        /// <summary>
        /// 父级Id
        /// </summary> 
        public Guid ParentId { get; set; }

        /// <summary>
        /// 菜单名称
        /// </summary>
        public string? MenuText { get; set; }

        /// <summary>
        /// 菜单类型
        /// 1：菜单功能
        /// 2：按钮功能
        /// </summary>
        public int MenuType { get; set; }

        /// <summary>
        /// 图标
        /// </summary> 
        public string? Icon { get; set; }

        /// <summary>
        /// 路由名称
        /// </summary> 
        public string? WebUrlName { get; set; }

        /// <summary>
        /// 前端Url地址--路由的地址
        /// </summary> 
        public string? WebUrl { get; set; }

        /// <summary>
        /// 保存Vue具体文件的某一个地址
        /// </summary> 
        public string? VueFilePath { get; set; }

        /// <summary>
        /// 是否叶节点
        /// </summary>
        public bool IsLeafNode { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int OrderBy { get; set; } 
    }
}