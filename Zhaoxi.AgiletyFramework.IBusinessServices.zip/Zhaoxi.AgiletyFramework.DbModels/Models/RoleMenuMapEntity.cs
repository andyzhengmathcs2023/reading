﻿
using System;

namespace Zhaoxi.AgiletyFramework.DbModels.Models
{
    /// <summary>
    /// 角色菜单关联表
    /// </summary> 
    public class RoleMenuMapEntity : BaseModel
    { 
        public int Id { get; set; }
         
        public int RoleId { get; set; }
 
        public Guid MenuId { get; set; }
    }
}
