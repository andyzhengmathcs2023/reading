﻿using System;
using System.Linq;
using System.Text;

namespace Zhaoxi.AgiletyFramework.DbModels.Models
{
    ///<summary>
    ///
    ///</summary>
    public partial class SystemLog
    { 
        public int Id { get; set; }
         
        public DateTime Date { get; set; }
         
        public string? Thread { get; set; }
         
        public string? Level { get; set; }
         
        public string? Logger { get; set; }
         
        public string? Message { get; set; }
         
        public string? Exception { get; set; }

    }
}
