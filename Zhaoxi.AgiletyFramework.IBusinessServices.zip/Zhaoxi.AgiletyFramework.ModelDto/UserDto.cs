﻿ 

namespace Zhaoxi.AgiletyFramework.ModelDto
{
    public class UserDto
    {
        public int UserId { get; set; }
        public string? Name { set; get; }

        public string? Password { set; get; }

        public int UserType { get; set; }
          
        public string? Phone { set; get; }

        public string? Mobile { set; get; }

        public string? Address { set; get; }

        public string? Email { set; get; }
        public string? QQ { set; get; }

        public string? WeChat { set; get; }

        public int Sex { set; get; }

        public int Status { set; get; }
         
        /// <summary>
        /// 用户头像
        /// </summary> 
        public string? Imageurl { set; get; }

        public DateTime LastLoginTime { set; get; }

        public List<int>? RoleIdList { get; set; }

        public List<int>? MenuIdList { get; set; }
    }
}