﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zhaoxi.AgiletyFramework.ModelDto
{
    public class AddUserDto
    {
        public int UserId { get; set; }
        public string? Name { set; get; }

        public string? Password { set; get; }

        public string? ConfirmPassword { set; get; }

        public string? ImageUrl { set; get; }

        public long? Phone { set; get; }

        public long? Mobile { set; get; }

        public string? Email { set; get; }

        public string? QQ { set; get; }

        public string? WeChat { set; get; }

        public string? Sex { set; get; }

        public string? Address { set; get; }

        public bool IsEnabled { get; set; }
    }
}
