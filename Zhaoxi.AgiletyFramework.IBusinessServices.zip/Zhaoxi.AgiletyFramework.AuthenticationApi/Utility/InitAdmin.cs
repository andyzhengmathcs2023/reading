﻿using Zhaoxi.AgiletyFramework.Commons.EnumEntity;
using Zhaoxi.AgiletyFramework.Commons;
using Zhaoxi.AgiletyFramework.DbModels.Models;
using Zhaoxi.AgiletyFramework.DbModels;

namespace Zhaoxi.AgiletyFramework.AuthenticationApi.Utility
{
    /// <summary>
    /// 初始化管理员信息
    /// </summary>
    public static class InitData
    { 
        /// <summary>
        /// 初始化管理员
        /// </summary>
        /// <param name="builder"></param>
        /// <exception cref="Exception"></exception>
        public static void InitAdmin(this WebApplicationBuilder builder)
        {
            //初始化管理员相关信息和权限
            string adminName = builder?.Configuration["Admin:name"];
            string adminPass = builder?.Configuration["Admin:password"];
            if (string.IsNullOrWhiteSpace(adminName) || string.IsNullOrWhiteSpace(adminPass))
            {
                throw new Exception("初始化系统，请配置管理员信息");
            }
            adminPass = MD5Encrypt.Encrypt(adminPass);
            int inItadministratorsid = 0;
            int inItadministratorsRoleid = 0;

            using (AgiletyDbContext context = new AgiletyDbContext(builder.Configuration.GetConnectionString("Default")))
            {
                #region 初始化管理员用户信息 
                UserEntity? _User = context.Set<UserEntity>()
               .Where(u => u.Name.Equals(adminName) && u.UserType == (int)UserTypeEnum.Administrator)
               .FirstOrDefault();

                if (_User != null)
                {
                    inItadministratorsid = _User.UserId;
                }
                else
                {
                    var userEntity = new UserEntity()
                    {
                        Name = adminName,
                        Password = adminPass,
                        UserType = (int)UserTypeEnum.Administrator,
                        CreateTime = DateTime.Now,
                        Sex = 1,
                        Status = (int)StatusEnum.Normal,
                        QQ = "1234567",
                    };

                    context.Set<UserEntity>()
                       .Add(userEntity);
                   
                    context.SaveChanges();

                    inItadministratorsid = userEntity.UserId;
                }

                #endregion

                #region 初始化系统管理员角色
                RoleEntity? _role = context.Set<RoleEntity>()
          .Where(u => "系统管理员".Equals(u.RoleName))
          .FirstOrDefault();



                if (_role != null)
                {
                    inItadministratorsRoleid = _role.RoleId;
                }
                else
                {

                    RoleEntity roleentity = new RoleEntity()
                    {
                        RoleName = "系统管理员",
                        Status = (int)StatusEnum.Normal,
                        ModifyTime = DateTime.Now,
                        CreateTime = DateTime.Now
                    };

                    context.Set<RoleEntity>()
                       .Add(roleentity);
                   
                    context.SaveChanges();
                    inItadministratorsRoleid = roleentity.RoleId;
                }
                #endregion

                #region 初始化管理员--用户角色关联关系
                UserRoleMapEntity? _userRoleMap = context.Set<UserRoleMapEntity>().Where(c => c.UserId == inItadministratorsid && c.RoleId == inItadministratorsRoleid).FirstOrDefault();
                if (_userRoleMap == null)
                {
                    context.Set<UserRoleMapEntity>()
                  .Add(new UserRoleMapEntity()
                  {
                      RoleId = inItadministratorsRoleid,
                      UserId = inItadministratorsid,
                      CreateTime = DateTime.Now,
                      ModifyTime = DateTime.Now,
                      Status = (int)StatusEnum.Normal,
                  });
                    context.SaveChanges();
                }
                #endregion

                #region 初始化系统管理员角色--角色和菜单关系
                List<RoleMenuMapEntity> removeMaplist =
                   context.Set<RoleMenuMapEntity>().Where(c => c.RoleId == inItadministratorsRoleid).ToList();
                context.Set<RoleMenuMapEntity>().RemoveRange(removeMaplist);


                List<RoleMenuMapEntity> roleMenuMapEntities = context.Set<MenuEntity>().Select(a => new RoleMenuMapEntity()
                {
                    RoleId = inItadministratorsRoleid,
                    MenuId = a.Id,
                    CreateTime = DateTime.Now,
                    ModifyTime = DateTime.Now,
                    Status = (int)StatusEnum.Normal,
                }).ToList();

                context.Set<RoleMenuMapEntity>().AddRange(roleMenuMapEntities);

                context.SaveChanges();
                #endregion

            }
        }

    }
}
