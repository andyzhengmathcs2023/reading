﻿
using Azure.Core;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Zhaoxi.AgiletyFramework.DbModels.Models;
using Zhaoxi.AgiletyFramework.ModelDto;

namespace Zhaoxi.AgiletyFramework.AuthenticationApi.Utility.JwtService
{

    /// <summary>
    /// 对称可逆加密实现
    /// </summary>
    public class JwtRSService : AbstractJwtService
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="jwtTokenOptions"></param>
        /// <param name="iMemoryCache"></param>
        public JwtRSService(IOptionsMonitor<JWTTokenOptions> jwtTokenOptions, IMemoryCache iMemoryCache) : base(jwtTokenOptions, iMemoryCache)
        { }

        /// <summary>
        /// 创建AccessToken
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public override string CreateAccessToken(UserDto user)
        {
            //准备有效载荷
            List<Claim> claimslist = base.UserToClaim(user);
            //准备加密key
            string accesstoken = WriteToken(claimslist.ToArray(), TimeSpan.FromMinutes(10));
            return accesstoken;
        }

        /// <summary>
        /// 创建RefreshToken
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public override string CreateRefreshToken(UserDto user)
        {
            //生成refreshToken 
            string refreshtokenGuid = Guid.NewGuid().ToString();
            Claim[] claimslist = new Claim[]
            {
                    new Claim("refreshtokenGuid", refreshtokenGuid)
            }; 
            string refreshToken = WriteToken(claimslist, TimeSpan.FromDays(5));
            //五天内有效
            _IMemoryCache.Set(refreshtokenGuid, user, DateTime.Now.AddDays(5));
            return refreshToken;
        }

        /// <summary>
        /// 非对称可逆加密实现
        /// </summary>
        /// <param name="claimslist"></param>
        /// <param name="timeSpan"></param>
        /// <returns></returns>
        private string WriteToken(Claim[] claimslist, TimeSpan timeSpan)
        {
            string keyDir = Directory.GetCurrentDirectory();
            if (RSAHelper.TryGetKeyParameters(keyDir, true, out RSAParameters keyParams) == false)
            {
                keyParams = RSAHelper.GenerateAndSaveKey(keyDir);
            }
            //准备加密key
            RsaSecurityKey key = new RsaSecurityKey(keyParams);
            //Sha256 加密方式
            SigningCredentials creds = new SigningCredentials(key, SecurityAlgorithms.RsaSha256Signature);
            JwtSecurityToken jwtSecurityToken = new JwtSecurityToken(
                 issuer: _JWTTokenOptions.Issuer,
                 audience: _JWTTokenOptions.Audience,
                 claims: claimslist.ToArray(),
                 expires: DateTime.Now.Add(timeSpan),
                 signingCredentials: creds);
            return new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
        }
    }
}
