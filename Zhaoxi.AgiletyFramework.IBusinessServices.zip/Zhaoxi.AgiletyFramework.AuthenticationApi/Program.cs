
using Microsoft.EntityFrameworkCore;
using Zhaoxi.AgiletyFramework.AuthenticationApi.Utility;
using Zhaoxi.AgiletyFramework.AuthenticationApi.Utility.JwtService;
using Zhaoxi.AgiletyFramework.BusinessServices;
using Zhaoxi.AgiletyFramework.DbModels;
using Zhaoxi.AgiletyFramework.IBusinessServices;
using Zhaoxi.AgiletyFramework.ModelDto;
using Zhaoxi.AgiletyFramework.WebCore.AuthorizationExtend;
using Zhaoxi.AgiletyFramework.WebCore.AutoMapExtend;
using Zhaoxi.AgiletyFramework.WebCore.CorsExtend;
using Zhaoxi.AgiletyFramework.WebCore.SwaggerExtend;

namespace Zhaoxi.AgiletyFramework.AuthenticationApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);


            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            //builder.Services.AddEndpointsApiExplorer();
            //builder.Services.AddSwaggerGen();


            #region ע��EFCore  
            // Add services to the container.
            //builder.Services.AddAuthorization();

            builder.Services.AddTransient<AbstractJwtService, JwtHSService>();
            builder.Services.AddTransient<IUserService, UserService>();
            builder.Services.Configure<JWTTokenOptions>(builder.Configuration.GetSection("JWTTokenOptions"));
            builder.Services.AddDbContext<DbContext, AgiletyDbContext>(option =>
            {
                option.UseSqlServer(builder.Configuration.GetConnectionString("Default"));
            });
            #endregion

            #region Swagger
            builder.Services.AddSwaggerExt("��Ϧ���ݺ�̨������Ȩ������Api�ĵ�", "��Ϧ���ݺ�̨������Ȩ������Api�ĵ�");
            #endregion

            #region ����Autommaper
            builder.Services.AddAutoMapper(typeof(AutoMapConfig));
            #endregion


            #region ���ÿ������
            builder.Services.AddCorsExt();
            #endregion


            #region ֧��MemoryCache
            builder.Services.AddMemoryCache();
            #endregion

            #region ע���Ȩ��Ȩˢ��Token�ķ���

            #endregion
            builder.RegisterRefreshTokenAuthorization();
            var app = builder.Build();


            app.LoginApi();

            // Configure the HTTP request pipeline.
            //if (app.Environment.IsDevelopment())
            //{
            //app.UseSwagger();
            //app.UseSwaggerUI();

            app.UseSwaggerExt("��Ϧ���ݺ�̨������Ŀ��֤������Api�ĵ�");
            //}

            //���� 
            app.UseCorsExt();


            if (app.Configuration["Admin:IsInit"] == "1")
            {
                builder.InitAdmin(); //��ʼ������Ա��Ϣ
            }


            app.UseAuthentication();
            app.UseAuthorization();


            app.Run();
        }
    }
}