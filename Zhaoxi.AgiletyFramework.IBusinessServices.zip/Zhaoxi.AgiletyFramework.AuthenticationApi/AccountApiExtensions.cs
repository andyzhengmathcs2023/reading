﻿
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Caching.Memory;
using System.Runtime.CompilerServices;
using Zhaoxi.AgiletyFramework.AuthenticationApi.Utility.JwtService;
using Zhaoxi.AgiletyFramework.Commons;
using Zhaoxi.AgiletyFramework.DbModels.Models;
using Zhaoxi.AgiletyFramework.IBusinessServices;
using Zhaoxi.AgiletyFramework.ModelDto;
using Zhaoxi.AgiletyFramework.WebCore.SwaggerExtend;

namespace Zhaoxi.AgiletyFramework.AuthenticationApi
{
    /// <summary>
    /// 
    /// </summary>
    public static class AccountApiExtensions
    {
        /// <summary>
        /// 登录颁发Token
        /// </summary>
        /// <param name="app"></param>
        public static void LoginApi(this WebApplication app)
        {
            //登录使用用户名和密码获取token
            app.MapPost("auth/Account", ([FromServices] IUserService userManagerService, [FromServices] AbstractJwtService _iJWTService, [FromServices] IMemoryCache iMemoryCache, User user) =>
            {
                UserDto? userDto = userManagerService.Login(user.Name, user.Password);
                if (userDto==null)
                {
                    return new ApiDataResult<object>()
                    {
                        Success = false,
                        Message = "用户名或密码错误"
                    };
                }

                //颁发Token
                string accesstoken = _iJWTService.CreateAccessToken(userDto);
                string refreshToken=_iJWTService.CreateRefreshToken(userDto);
                return new ApiDataResult<object>()
                {
                    Success = true,
                    Message = "登录成功",
                    Data = new
                    {
                        RefreshToken = refreshToken,
                        Accesstoken = accesstoken
                    }
                };
            }).WithGroupName(ApiVersions.V1.ToString())
            .WithDescription("登录-使用用户名密码获取token");
             
            ////刷新Token
            app.MapGet("auth/Account", [Authorize(AuthenticationSchemes= JwtBearerDefaults.AuthenticationScheme)]
            ([FromServices] AbstractJwtService _iJWTService, [FromServices] IMemoryCache _IMemoryCache, HttpContext context) =>
            {
                string refreshtokenGuid = context?.User?.FindFirst("refreshtokenGuid")?.Value;
                if (string.IsNullOrWhiteSpace(refreshtokenGuid))
                {
                    return new ApiResult()
                    {
                        Success = false,
                        Message = "已过期需要重新登录",
                    };
                }
                UserDto userDto = _IMemoryCache.Get<UserDto>(refreshtokenGuid);
                if (userDto == null)
                {
                    return new ApiResult()
                    {
                        Success = false,
                        Message = "已过期需要重新登录",
                    };
                }
                string token = _iJWTService.CreateAccessToken(userDto);  
                return new ApiDataResult<string>()
                {
                    Success = true,
                    Message = "Token刷新成功",
                    Data = token
                };
            }).WithGroupName(ApiVersions.V1.ToString())
            .WithDescription("刷新Token,使用RreshToken换新Token"); ;
        }

    }
}
