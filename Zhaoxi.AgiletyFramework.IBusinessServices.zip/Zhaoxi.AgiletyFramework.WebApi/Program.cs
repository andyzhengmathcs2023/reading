
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using System;
using Zhaoxi.AgiletyFramework.BusinessServices;
using Zhaoxi.AgiletyFramework.DbModels;
using Zhaoxi.AgiletyFramework.IBusinessServices;
using Zhaoxi.AgiletyFramework.WebApi.Utility.AutofacExtend;
using Zhaoxi.AgiletyFramework.WebCore.AuthorizationExtend;
using Zhaoxi.AgiletyFramework.WebCore.AutoMapExtend;
using Zhaoxi.AgiletyFramework.WebCore.CorsExtend;
using Zhaoxi.AgiletyFramework.WebCore.DownloadFileExtend;
using Zhaoxi.AgiletyFramework.WebCore.SwaggerExtend;

namespace Zhaoxi.AgiletyFramework.WebApi
{
    /// <summary>
    /// 
    /// </summary>
    public class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            #region IOC����

            //Autofac  ���ܸߣ�����Ҳ�Ƚ���ȫ 
            builder.Services.AddDbContext<DbContext, AgiletyDbContext>(builderOptions =>
            {
                builderOptions.UseSqlServer(builder.Configuration.GetConnectionString("Default"));
            });
            //builder.Services.AddTransient<IUserService, UserService>();

            #endregion

            #region Autofac---�������滻���õ����������Ǻ����õ�ServiceCollection��������ġ�

            //Autofac
            //Autofac.Extensions.DependencyInjection 
            builder.Host.AutofacRegister(); //����Autofac

            #endregion

            #region Automapperע��
            builder.Services.AddAutoMapper(typeof(AutoMapConfig));
            #endregion


            //log4Net���룺
            builder.Logging.AddLog4Net("CfgFile/log4net.Config");

            builder.Services.AddControllers();

            //����
            builder.Services.AddCorsExt();

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle

            #region Swagger
            builder.Services.AddSwaggerExt("��Ϧ���ݺ�̨������ĿʵսApi�ĵ�", "��Ϧ���ݺ�̨������ĿʵսApi�ĵ�");
            #endregion


            #region jwt��Ȩ��Ȩ
            builder.RegisterAuthorization();
            #endregion


            var app = builder.Build();

            app.UseCorsExt();
             
            //��չһ���м������ȡͼƬ
            app.UseDownloadImages(Directory.GetCurrentDirectory());
             
            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwaggerExt("��Ϧ���ݺ�̨������ĿʵսApi�ĵ�");
            }


            app.UseAuthentication();
            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}