﻿using Autofac.Extensions.DependencyInjection;
using Autofac;
using Zhaoxi.AgiletyFramework.BusinessServices;
using Zhaoxi.AgiletyFramework.IBusinessServices;
using Autofac.Extras.DynamicProxy;
using Zhaoxi.AgiletyFramework.AutofacAOP.AopExtend;

namespace Zhaoxi.AgiletyFramework.WebApi.Utility.AutofacExtend
{

    /// <summary>
    /// Autofac的扩展
    /// </summary>
    public static class AutofacExtensions
    {
        /// <summary>
        /// 配置的Autofac的注册
        /// </summary>
        /// <param name="host"></param>
        public static void AutofacRegister(this ConfigureHostBuilder host)
        {
            host.UseServiceProviderFactory(new AutofacServiceProviderFactory());//指定Provider的工厂为AutofacServiceProviderFactory
            host.ConfigureContainer<ContainerBuilder>(ConfigurationBinder =>
            {
                //在这里就是可以注册IOC中  抽象和具体之间的关系
                ConfigurationBinder.RegisterType<UserService>().As<IUserService>()

                //通过接口来支持
                //.EnableInterfaceInterceptors();  //nuget： Autofac.Extras.DynamicProxy 

                //通过类来支持Aop
                .EnableClassInterceptors();

                ConfigurationBinder.RegisterType<CustomLogInterceptor>();

                ConfigurationBinder.RegisterType<MenuService>().As<IMenuService>();


            });
        }
    }
}
