using Autofac;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Zhaoxi.AgiletyFramework.BusinessServices;
using Zhaoxi.AgiletyFramework.Commons;
using Zhaoxi.AgiletyFramework.DbModels;
using Zhaoxi.AgiletyFramework.DbModels.Models;
using Zhaoxi.AgiletyFramework.IBusinessServices;
using Zhaoxi.AgiletyFramework.ModelDto;
using Zhaoxi.AgiletyFramework.WebCore.SwaggerExtend;

namespace Zhaoxi.AgiletyFramework.WebApi.Controllers
{

    /// <summary>
    /// ����һ�����ԵĿ�����
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    [ApiExplorerSettings(IgnoreApi = false, GroupName = nameof(ApiVersions.V1))]
    public class TestController : ControllerBase
    {
        private readonly ILogger<TestController> _Logger;
        private readonly DbContext _Context;
        private readonly IUserService _IUserService;

        private readonly IMapper _IMapper;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        /// <param name="iUserService"></param>
        /// <param name="componentContext"></param>
        public TestController(ILogger<TestController> logger, DbContext context, IUserService iUserService, IComponentContext componentContext, IMapper iMapper)
        {
            _Context = context;
            _Logger = logger;
            _Logger.LogInformation($"{this.GetType().FullName} ���캯��ִ��~~");
            _Logger.LogWarning($"{this.GetType().FullName} ���캯��ִ��~~");
            _IUserService = iUserService;
            _IUserService = componentContext.Resolve<IUserService>();
            _IMapper = iMapper;
        }


        /// <summary>
        /// ����һ��get api
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public object Get()
        {
            //1.��֤����
            //2.����ҵ���߼�
            //3.��¼��־
            //4.��ѯ����
            //5.�޸�����

            //���ֲ㣬����֣�ÿһ�㶼�Ƕ�����ҵ���߼���
            //1. ְ���������

            //string connectionString = "Data Source=PC-202206030027;Initial Catalog=Zhaoxi.AgiletyFramework.DB;Persist Security Info=True;User ID=sa;Password=sa123;TrustServerCertificate=true";
            //using (AgiletyDbContext context = new AgiletyDbContext(connectionString))
            //{
            //    UserEntity user = context.UserEntities.OrderByDescending(c => c.UserId).FirstOrDefault();
            //    return new JsonResult(user);
            //} 
            //UserEntity user = _Context.Set<UserEntity>().OrderByDescending(c => c.UserId).FirstOrDefault();

            UserEntity user = _IUserService.Set<UserEntity>().OrderByDescending(c => c.UserId).FirstOrDefault();


            UserEntity user1 = _IUserService.Find<UserEntity>(1);


            //����Aop
            _IUserService.SetUserAndCompany();
            _IUserService.ShowUserAndCompany();

            return new JsonResult(user);
        }

        /// <summary>
        /// ����һ��post api
        /// </summary>
        /// <returns></returns>
        [HttpPost()]
        public IActionResult Post()
        { 
            UserEntity user = _IUserService.Set<UserEntity>().OrderByDescending(c => c.UserId).FirstOrDefault();
            //�����������Ҫ����5���ֶΣ����Ǻ����ݿ�ӳ���ʵ����10���ֶΡ�  ���ʹ�����ʵ�������ء�  ����Ҫ����10���ֶΡ� ����������ķ��أ�

            //Entity  ת����   Dto�Ĺ���

            //Automapper
            UserDto userDto= _IMapper.Map<UserEntity, UserDto>(user);

            return new JsonResult(new ApiDataResult<UserDto>()
            {
                Success = true,
                Message = "��ѯ�û�",
                Data = userDto,
                OValue = null
            });
        }

        [HttpPut()]
        public IEnumerable<WeatherForecast> Put()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
            })
            .ToArray();
        }

        [HttpDelete()]
        public IEnumerable<WeatherForecast> Delete()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
            })
            .ToArray();
        }
    }
}