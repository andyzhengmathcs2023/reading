﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Abstractions;
using Zhaoxi.AgiletyFramework.Commons;
using Zhaoxi.AgiletyFramework.Commons.EnumEntity;
using Zhaoxi.AgiletyFramework.DbModels.Models;
using Zhaoxi.AgiletyFramework.IBusinessServices;
using Zhaoxi.AgiletyFramework.ModelDto;
using Zhaoxi.AgiletyFramework.WebCore.SwaggerExtend;

namespace Zhaoxi.AgiletyFramework.WebApi.Controllers
{

    /// <summary>
    /// Api控制器，用户相关的Api
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = false, GroupName = nameof(ApiVersions.V1))]
    public class LogController : ControllerBase
    {
        private readonly ILogger<LogController> _logger;
        private readonly IUserService _IUserService;
        private readonly IMapper _IMapper;   //AutoMapper映射使用

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="iUserService"></param>
        /// <param name="iMapper"></param>
        public LogController(ILogger<LogController> logger, IUserService iUserService, IMapper iMapper)
        {
            _logger = logger;
            _IUserService = iUserService;
            _IMapper = iMapper;
        }


        /// <summary>
        /// 获取系统日志的分页列表
        /// </summary>
        /// <param name="pageindex"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchaString"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{pageindex:int}/{pageSize:int}")]
        [Route("{pageindex:int}/{pageSize:int}/{searchaString}")]
        public async Task<JsonResult> GetUserPageAsync(int pageindex, int pageSize, string? searchaString = null)
        {
            PagingData<SystemLog> paging = _IUserService
               .QueryPage<SystemLog, DateTime>(!string.IsNullOrWhiteSpace(searchaString) ? c => c.Message.Contains(searchaString) : a => true, pageSize, pageindex, c => c.Date, false);

            PagingData<SystemLogDto> pagingResult = _IMapper.Map<PagingData<SystemLog>, PagingData<SystemLogDto>>(paging);

            JsonResult result = new JsonResult(new ApiDataResult<PagingData<SystemLogDto>>()
            {
                Data = pagingResult,
                Success = true,
                Message = "日志分页列表"
            });
            return await Task.FromResult(result);
        } 
    }
}
