﻿using Autofac.Extras.DynamicProxy;
using Zhaoxi.AgiletyFramework.AutofacAOP.AopExtend;
using Zhaoxi.AgiletyFramework.ModelDto;

namespace Zhaoxi.AgiletyFramework.IBusinessServices
{


    [Intercept(typeof(CustomLogInterceptor))]  //通过接口方式来完成对于Aop的支持
    public interface IUserService: IBaseService
    {

        /// <summary>
        /// 登录功能
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public UserDto? Login(string userName, string password);

        public void ShowUserAndCompany();

        public void SetUserAndCompany();

        //public void Add();

        //public void Delete();

        //public void Update();

        //public void Query();
    }
}