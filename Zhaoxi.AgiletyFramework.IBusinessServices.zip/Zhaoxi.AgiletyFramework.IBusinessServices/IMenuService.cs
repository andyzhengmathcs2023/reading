﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zhaoxi.AgiletyFramework.ModelDto;

namespace Zhaoxi.AgiletyFramework.IBusinessServices
{
    public interface IMenuService: IBaseService
    {
        /// <summary>
        /// 根据用户Id计算出用户拥有哪些菜单
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<MenuTreeDto> GetMenusTreeList(int userId);



        //public void Add();

        //public void Delete();

        //public void Update();

        //public void Query();
    }
}
