

//corewebapi 服务器 根地址
export const apiUrl = () => "http://localhost:5068/";

export const authURL = () => "http://localhost:5051/";