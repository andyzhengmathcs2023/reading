<template>
    <el-card class="box-card">
        <el-row>
            <el-form class="demo-form-inline" :inline="true">
                <el-form-item label="关键字" style="color:aliceblue">
                    <div class="block">
                        <el-input v-model="searchQuery.searchString" placeholder="日志关键字..." />
                    </div>
                </el-form-item>
                <el-form-item style="color:aliceblue">
                    <el-button type="primary" @click="logQuery">查询</el-button>
                </el-form-item>
            </el-form>
        </el-row>
        <el-row>
            <el-table :data="tableData" style="width: 100%" :row-class-name="tableRowClassName">
                <el-table-column type="index" label="序号" width="60" />
                <el-table-column prop="date" label="时间" />
                <el-table-column prop="thread" label="线程Id" />
                <el-table-column prop="logger" label="日志发生类" />
                <!-- <el-table-column prop="message" label="日志消息" /> -->

                <el-table-column prop="message" label="日志消息">
                    <template #default="scope">
                        <div style="display: flex; align-items: center">
                            <el-popover :width="300"
                                popper-style="box-shadow: rgb(14 18 22 / 35%) 0px 10px 38px -10px, rgb(14 18 22 / 20%) 0px 10px 20px -15px; padding: 20px;">
                                <template #reference>
                                    {{ scope.row.exception}}
                                </template>
                                <template #default>
                                    <div class="demo-rich-conent" style="display: flex; gap: 16px; flex-direction: column">
                                        <div>
                                            {{ scope.row.exception }}
                                        </div>
                                    </div>
                                </template>
                            </el-popover>
                        </div>
                    </template>
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination v-model:current-page="searchQuery.currentPage" v-model:page-size="searchQuery.pageSize"
                    :page-sizes="[10, 20, 30, 40]" :small="small" :disabled="disabled" :background="background"
                    layout="total,sizes, prev, pager, next,jumper" :total="searchQuery.recordCount" @size-change="logQuery"
                    @current-change="logQuery">
                </el-pagination>
            </div>
        </el-row>
    </el-card>
</template>

<script setup>


import { ref, onMounted } from 'vue';
// import axios from "axios";
import service from "../../common/apiRequest";
import { ElMessage } from 'element-plus'

//查询条件绑定对象
const searchQuery = ref({
    currentPage: 1,
    pageSize: 10,
    recordCount: 0,
    searchString: ""
})

//列表数据
let tableData = ref([]);

onMounted(async () => {
    logQuery();
});

let logQuery = async () => {
    var url = `/api/log/${searchQuery.value.currentPage}/${searchQuery.value.pageSize}`;
    var searchString = searchQuery.value.searchString;
    if (searchString) {
        url = `/api/User/${searchQuery.value.currentPage}/${searchQuery.value.pageSize}/${searchString}`;
    }
    let reponse = await service.get(url);
    let { success, message, data, oValue } = reponse.data;

    if (success == true) {
        tableData.value = data.dataList;
        searchQuery.value.recordCount = data.recordCount;
    }
    else {
        alert(message);
    }
}


</script>



<style>
.el-table .warning-row {
    --el-table-tr-bg-color: var(--el-color-warning-light-9);
}

.el-table .success-row {
    --el-table-tr-bg-color: var(--el-color-success-light-9);
}
</style>