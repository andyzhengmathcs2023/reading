
<template> 
  <RouterView />   通过路由配置
</template>

<script setup>
 
</script>

 