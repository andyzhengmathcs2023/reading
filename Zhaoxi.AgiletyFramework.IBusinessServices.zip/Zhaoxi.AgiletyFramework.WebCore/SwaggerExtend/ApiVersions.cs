﻿namespace Zhaoxi.AgiletyFramework.WebCore.SwaggerExtend
{

    /// <summary>
    ///  Api版本枚举
    /// </summary>
    public enum ApiVersions
    {
        V1,
        V2,
        V3,
        V4
    }
}
