﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zhaoxi.AgiletyFramework.WebCore.DownloadFileExtend
{
    public static class DownloadImagesExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="app"></param>
        /// <param name="directoryPath"></param>
        public static void UseDownloadImages(this IApplicationBuilder app,string directoryPath)
        {
            app.UseMiddleware<DownloadImagesMiddleware>(Directory.GetCurrentDirectory());
        }
    }
}
