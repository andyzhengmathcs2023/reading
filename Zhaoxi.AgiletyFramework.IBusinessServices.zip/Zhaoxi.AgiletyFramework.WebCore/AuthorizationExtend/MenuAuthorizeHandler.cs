﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Options;
using System.Security.Claims;
 
using Zhaoxi.AgiletyFramework.IBusinessServices;

namespace Zhaoxi.AgiletyFramework.WebCore.AuthorizationExtend
{

    /// <summary>
    /// 核心判断
    /// 在这里就可以做自己要做的业务判断
    /// </summary>
    public class MenuAuthorizeHandler : AuthorizationHandler<MenuAuthorizeRequirement>
    {

        private readonly IUserService _IUserService;

        /// <summary>
        /// 构造函数注入
        /// </summary>
        /// <param name="iUserService"></param>

        public MenuAuthorizeHandler(IUserService iUserService)
        {
            _IUserService = iUserService;
        }



        /// <summary>
        /// 验证核心业务逻辑
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <returns></returns>
        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, MenuAuthorizeRequirement requirement)
        {
            //if (context.User.Claims == null || context.User.Claims.Count() <= 0)
            //{
            //    context?.Fail();
            //}
            //else if (context.User.IsInRole("admin"))
            //{
                context?.Succeed(requirement);//只要执行这句话就表示验证通过了
            //} 
            await Task.CompletedTask;
        }
    }
}
