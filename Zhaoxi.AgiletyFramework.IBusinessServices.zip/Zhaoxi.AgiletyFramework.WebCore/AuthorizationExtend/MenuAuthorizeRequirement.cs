﻿using Microsoft.AspNetCore.Authorization;

namespace Zhaoxi.AgiletyFramework.WebCore.AuthorizationExtend
{
    /// <summary>
    /// 
    /// </summary>
    public class MenuAuthorizeRequirement : IAuthorizationRequirement
    {

    }
}
